#Set Environment
wd <- getwd()
setwd(wd)

library(stringr)
library(RColorBrewer)
library(plotrix)
library(reshape2)
library(dplyr)
library(ggplot2)

#Read and Process Data
data <- read.csv("examdata_4me312-ht20_Maath Musleh.csv", header = T, stringsAsFactors = F)
coul <- brewer.pal(5, "Set2")


data$B_use[data$B_use==5] <-'one'
data$B_use[data$B_use==4] <-'two'
data$B_use[data$B_use==1] <- 5
data$B_use[data$B_use==2] <-4
data$B_use[data$B_use=='one'] <- 1
data$B_use[data$B_use=='two'] <- 2
data$B_use <- as.numeric(data$B_use)
#Barplot of Job,
par(mar = rep(2, 4), mfrow=c(1,3))
myvars <- c('job')
job <- data[myvars]
job_count <- table(job)

theplot<-barplot(job_count,
                 main="Job field of participants",
                 xlab="Field",
                 ylab="Count",
                 ylim=c(0,50),
                 col = coul)
text(theplot, job_count-5 , paste(round(job_count/sum(job_count)*100,1), "%") ,cex=1)

#Barplot of Job,
myvars <- c('used_A')
used_A <- data[myvars]
used_A_count <- table(used_A)
used_A_count
theplot<-barplot(used_A_count,
                 main="Do users have previous experience with System A?",
                 xlab="Experience?",
                 ylab="Count",
                 ylim=c(0,60),
                 col = coul)
text(theplot, used_A_count-5 , paste(round(used_A_count/sum(used_A_count)*100,1), "%") ,cex=1)

#Experience,
myvars <- c('experience')
experience <- data[myvars]
summary(experience)

boxplot(experience, data, main="Experience distribution",
        xlab="experience",col = coul, ylab="Level of Experience", varwidth= TRUE, ylim=c(1,7))

#Oder
myvars <- c('order')
order <- data[myvars]
order_count <- table(order)
theplot<-barplot(order_count,
                 main="In which order were systems evaluated?",
                 xlab="Order",
                 ylab="Count",
                 ylim=c(0,50),
                 col = coul)
text(theplot, order_count-5 , paste(round(order_count/sum(order_count)*100,1), "%") ,cex=1)

summary(data$A_time)
summary(data$B_time)
summary(data$A_score)
summary(data$B_score)

#General Population
par(mar = rep(2, 4), mfrow=c(2,2))
boxplot(data$A_use, 
        main="Usability Score of System A", varwidth= TRUE,  
        xlab="System A", ylab="Score", ylim=c(1, 5))
boxplot(data$B_use, 
        main="Usability Score of System B", varwidth= TRUE,  
        xlab="System B", ylab="Score", ylim=c(1, 5))
boxplot(data$A_perf, 
        main="Performance Score of System A", varwidth= TRUE,  
        xlab="System A", ylab="Score", ylim=c(1, 5))
boxplot(data$B_perf, 
        main="Performance Score of System B", varwidth= TRUE,  
        xlab="System B", ylab="Score", ylim=c(1, 5))
boxplot(data$A_score, 
        main="User Score of System A Task", varwidth= TRUE,  
        xlab="Users' Score", ylab="Score", ylim=c(0, 100))
boxplot(data$B_score, 
        main="User Score of System B Task", varwidth= TRUE,  
        xlab="Users' Score", ylab="Score", ylim=c(0, 100))
min <- min(data$A_time)/60
max <- max(data$A_time)/60
boxplot(data$A_time/60, 
        main="Completeion time for System A Task", varwidth= TRUE,  
        xlab="Completion Time", ylab="Time", ylim=c(0, max+1))
min <- min(data$B_time)/60
max <- max(data$B_time)/60
boxplot(data$B_time/60, 
        main="Completeion time for System B Task", varwidth= TRUE,  
        xlab="Completion Time", ylab="Time", ylim=c(0, max+1))


#SYSTEM LOGS

par(mar = rep(2, 4), mfrow=c(3,2))
boxplot(data$A_score~data$used_A, 
        main="Task A score vs System A experience", varwidth= TRUE,  
        xlab="Previous Experience", ylab="Score")

boxplot(data$B_score~data$used_A, 
        main="Task B score vs System A experience", varwidth= TRUE,  
        xlab="Previous Experience", ylab="Score")

boxplot(data$A_score~data$experience, 
        main="Task A score vs similar experience", varwidth= TRUE,  
        xlab="Previous Experience", ylab="Score")

boxplot(data$B_score~data$experience, 
        main="Task B score vs similar experience", varwidth= TRUE,  
        xlab="Previous Experience", ylab="Score")

boxplot(data$A_score~data$job, 
        main="Task A score vs Job", varwidth= TRUE,  
        xlab="Job", ylab="Score")

boxplot(data$B_score~data$job, 
        main="Task B score vs Job", varwidth= TRUE,  
        xlab="Job", ylab="Score")

boxplot(data$A_time/60~data$used_A, 
        main="System A time vs system A experience", varwidth= TRUE,  
        xlab="Previous Experience", ylab="Time in mins")

boxplot(data$B_time/60~data$used_A, 
        main="System B time vs System A experience", varwidth= TRUE,  
        xlab="Previous Experience", ylab="Time in mins")

boxplot(data$A_time/60~data$experience, 
        main="System A time vs similar experience", varwidth= TRUE,  
        xlab="Previous Experience", ylab="Time in mins")

boxplot(data$B_time/60~data$experience, 
        main="System B time vs similar experience", varwidth= TRUE,  
        xlab="Previous Experience", ylab="Time in mins")

boxplot(data$A_time/60~data$job, 
        main="System A time vs Field", varwidth= TRUE,  
        xlab="Job", ylab="Time in mins")

boxplot(data$B_time/60~data$job, 
        main="System B time vs Field", varwidth= TRUE,  
        xlab="Job", ylab="Time in mins")



#REPORTED EVALUATION
par(mar = rep(2, 4), mfrow=c(3,2))
boxplot(data$A_use~data$used_A, 
        main="Usability of A vs System A experience", varwidth= TRUE,  
        xlab="Previous Experience", ylab="Score", ylim=c(1, 5))

boxplot(data$B_use~data$used_A, 
        main="Usability of B vs System A experience", varwidth= TRUE,  
        xlab="Previous Experience", ylab="Score", ylim=c(1, 5))

boxplot(data$A_use~data$experience, 
        main="Usability of A vs similar experience", varwidth= TRUE,  
        xlab="Previous Experience", ylab="Score", ylim=c(1, 5))

boxplot(data$B_use~data$experience, 
        main="Usability of B vs similar experience", varwidth= TRUE,  
        xlab="Previous Experience", ylab="Score", ylim=c(1, 5))

boxplot(data$A_use~data$job, 
        main="Usability of A vs Job", varwidth= TRUE,  
        xlab="Job", ylab="Score", ylim=c(1, 5))

boxplot(data$B_use~data$job, 
        main="Usability of B vs Job", varwidth= TRUE,  
        xlab="Job", ylab="Score", ylim=c(1, 5))

boxplot(data$A_perf~data$used_A, 
        main="Performance of A vs system A experience", varwidth= TRUE,  
        xlab="Previous Experience", ylab="Score", ylim=c(1, 5))

boxplot(data$B_perf~data$used_A, 
        main="Performance of B vs System A experience", varwidth= TRUE,  
        xlab="Previous Experience", ylab="Score", ylim=c(1, 5))

boxplot(data$A_perf~data$experience, 
        main="Performance of A vs similar experience", varwidth= TRUE,  
        xlab="Previous Experience", ylab="Score", ylim=c(1, 5))

boxplot(data$B_perf~data$experience, 
        main="Performance of B vs similar experience", varwidth= TRUE,  
        xlab="Previous Experience", ylab="Score", ylim=c(1, 5))

boxplot(data$A_perf~data$job, 
        main="Performance of A vs Field", varwidth= TRUE,  
        xlab="Job", ylab="Score", ylim=c(1, 5))

boxplot(data$B_perf~data$job, 
        main="Performance of B vs Field", varwidth= TRUE,  
        xlab="Job", ylab="Score", ylim=c(1, 5))


par(mar = rep(2, 4), mfrow=c(1,2))
plot(sort(data$A_score),xlab=sprintf("D%d (M=%.2f,SD=%.2f)",1,mean(data$A_score),sd(data$A_score)),ylab="",xlim=c(0,83),ylim=c(0,100),pch=19)
plot(sort(data$B_score),xlab=sprintf("D%d (M=%.2f,SD=%.2f)",2,mean(data$B_score),sd(data$B_score)),ylab="",xlim=c(0,83),ylim=c(0,100),pch=19)

par(mar = rep(2, 4), mfrow=c(2,2))

hist(data$A_score,breaks=seq(0,100,10),freq=FALSE,ylim=c(0,.05),
     main="",xlab=sprintf("D%d (M=%.2f,SD=%.2f)",1,mean(data$A_score),sd(data$A_score)),
     yaxt='n'
)
axis(2,at=c(0,.1),labels = c(0,.1))
C=curve(dnorm(x,mean=mean(data$A_score),sd=sd(data$A_score)),add=TRUE,lwd=2)
SWt = shapiro.test(data$A_score)
text(20, 0.04,
     labels=sprintf("Normality for Score of Task A was tested using the Shapiro-Wilks test\n(W=%.2f; p=%.2f)",SWt$statistic, SWt$p.value),
     pos=4,cex=.75)


hist(data$B_score,breaks=seq(0,100,10),freq=FALSE,ylim=c(0,.05),
     main="",xlab=sprintf("D%d (M=%.2f,SD=%.2f)",2,mean(data$B_score),sd(data$B_score)),
     yaxt='n'
)
axis(2,at=c(0,.1),labels = c(0,.1))
C=curve(dnorm(x,mean=mean(data$B_score),sd=sd(data$B_score)),add=TRUE,lwd=2)
SWt = shapiro.test(data$B_score)
text(20, 0.04,
     labels=sprintf("Normality for Score of Task B was tested using the Shapiro-Wilks test\n(W=%.2f; p=%.2f)",SWt$statistic, SWt$p.value),
     pos=4,cex=.75)

hist(data$A_time,breaks=seq(0,700,60),freq=FALSE,ylim=c(0,.005),
     main="",xlab=sprintf("D%d (M=%.2f,SD=%.2f)",1,mean(data$A_time),sd(data$A_time)),
     yaxt='n'
)
axis(2,at=c(0,.1),labels = c(0,.1))
C=curve(dnorm(x,mean=mean(data$A_time),sd=sd(data$A_time)),add=TRUE,lwd=2)
SWt = shapiro.test(data$A_time)
text(20, 0.0042,
     labels=sprintf("Normality for Score of Task A was tested using the Shapiro-Wilks test\n(W=%.2f; p=%.2f)",SWt$statistic, SWt$p.value),
     pos=4,cex=.75)


hist(data$B_time,breaks=seq(0,700,60),freq=FALSE,ylim=c(0,.005),
     main="",xlab=sprintf("D%d (M=%.2f,SD=%.2f)",2,mean(data$B_time),sd(data$B_time)),
     yaxt='n'
)
axis(2,at=c(0,.01),labels = c(0,.01))
C=curve(dnorm(x,mean=mean(data$B_time),sd=sd(data$B_time)),add=TRUE,lwd=2)
SWt = shapiro.test(data$B_time)
text(20, 0.0042,
     labels=sprintf("Normality for Time for Task B was tested using the Shapiro-Wilks test\n(W=%.2f; p=%.2f)",SWt$statistic, SWt$p.value),
     pos=4,cex=.75)

Ttest = t.test(data$A_score, data$B_score, paired = TRUE, alternative = "two.sided")
Ttest 

shapiro.test(data$A_score)
shapiro.test(data$B_score)
shapiro.test(data$A_time)
shapiro.test(data$B_time)
#Chisq-tests

matrix <- table(data$A_use, data$B_use)
cst <- chisq.test(matrix)
cst$p.value

summary(data$A_use)
summary(data$B_use)

sd(data$A_use)
sd(data$B_use)

use_diff <-  data$B_use - data$A_use
par(mar = rep(2, 4), mfrow=c(1,1))
boxplot(use_diff, 
        main="Difference in evaluationg System A and B for each particpant", varwidth= TRUE,  
        xlab="Difference in score between A and B", ylab="Score", ylim=c(-4, 4))
summary(use_diff)
sd(use_diff)
matrix <- table(use_diff, data$job)
cst <- chisq.test(matrix)
cst$p.value

matrix <- table(use_diff, data$experience)
cst <- chisq.test(matrix)
cst$p.value

matrix <- table(use_diff, data$order)
cst <- chisq.test(matrix)
cst$p.value

matrix <- table(use_diff, data$used_A)
cst <- chisq.test(matrix)
cst$p.value




boxplot(use_diff~data$job, 
        main="Difference in evaluationg System A and B based on Job", varwidth= TRUE,  
        xlab="Job", ylab="Score Difference", ylim=c(-4, 4))

boxplot(use_diff~data$experience, 
        main="Difference in evaluationg System A and B based on similar experience", varwidth= TRUE,  
        xlab="Job", ylab="Score Difference", ylim=c(-4, 4))

boxplot(use_diff~data$used_A, 
        main="Difference in evaluationg System A and B based on experience with System A", varwidth= TRUE,  
        xlab="Job", ylab="Score Difference", ylim=c(-4, 4))

boxplot(use_diff~data$order, 
        main="Difference in evaluationg System A and B based on order of Evaluation", varwidth= TRUE,  
        xlab="Job", ylab="Score Difference", ylim=c(-4, 4))
matrix <- table(use_diff, data$order)
cst <- chisq.test(matrix)
cst$p.value


perf_diff <-  data$B_perf - data$A_perf
par(mar = rep(2, 4), mfrow=c(1,1))
boxplot(perf_diff, 
        main="Difference in evaluationg performance between System A and B for each particpant", varwidth= TRUE,  
        xlab="Difference in score between A and B", ylab="Score", ylim=c(-4, 4))
summary(perf_diff)
sd(perf_diff)
matrix <- table(data$A_perf, data$B_perf)
cst <- chisq.test(matrix)
cst$p.value

boxplot(perf_diff~data$job, 
        main="Difference in evaluationg performance between System A and B based on Job", varwidth= TRUE,  
        xlab="Job", ylab="Score Difference", ylim=c(-4, 4))

boxplot(perf_diff~data$experience, 
        main="Difference in evaluationg performance between  System A and B based on similar experience", varwidth= TRUE,  
        xlab="Job", ylab="Score Difference", ylim=c(-4, 4))

boxplot(perf_diff~data$used_A, 
        main="Difference in evaluationg performance between  System A and B based on experience with System A", varwidth= TRUE,  
        xlab="Job", ylab="Score Difference", ylim=c(-4, 4))

boxplot(perf_diff~data$order, 
        main="Difference in evaluationg performance between  System A and B based on order of Evaluation", varwidth= TRUE,  
        xlab="Job", ylab="Score Difference", ylim=c(-4, 4))


matrix <- table(perf_diff, data$job)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(perf_diff, data$experience)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(perf_diff, data$used_A)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(perf_diff, data$order)
cst <- chisq.test(matrix)
cst$p.value


matrix <- table(data$A_perf, data$B_perf)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$A_time, data$B_time)
cst <- chisq.test(matrix)
cst$p.value


matrix <- table(data$A_use, data$A_perf)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$A_use, data$A_score)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$A_use, data$A_time)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$B_use, data$B_perf)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$B_use, data$B_score)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$B_use, data$B_time)
cst <- chisq.test(matrix)
cst$p.value

matrix <- table(data$A_perf, data$A_score)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$A_use, data$A_time)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$B_perf, data$B_score)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$B_perf, data$B_time)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$A_score, data$A_time)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$B_score, data$B_time)
cst <- chisq.test(matrix)
cst$p.value

matrix <- table(data$A_use, data$job)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$A_use, data$experience)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$A_use, data$order)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$A_use, data$used_A)
cst <- chisq.test(matrix)
cst$p.value

matrix <- table(data$B_use, data$job)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$B_use, data$experience)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$B_use, data$order)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$B_use, data$used_A)
cst <- chisq.test(matrix)
cst$p.value

matrix <- table(data$A_perf, data$job)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$A_perf, data$experience)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$A_perf, data$order)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$A_perf, data$used_A)
cst <- chisq.test(matrix)
cst$p.value

matrix <- table(data$B_perf, data$job)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$B_perf, data$experience)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$B_perf, data$order)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$B_perf, data$used_A)
chisq.test(matrix)cst <- chisq.test(matrix)
cst$p.value

matrix <- table(data$A_score, data$job)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$A_score, data$experience)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$A_score, data$order)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$A_score, data$used_A)
cst <- chisq.test(matrix)
cst$p.value

matrix <- table(data$B_score, data$job)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$B_score, data$experience)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$B_score, data$order)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$B_score, data$used_A)
cst <- chisq.test(matrix)
cst$p.value

matrix <- table(data$A_time, data$job)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$A_time, data$experience)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$A_time, data$order)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$A_time, data$used_A)
cst <- chisq.test(matrix)
cst$p.value

matrix <- table(data$B_time, data$job)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$B_time, data$experience)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$B_time, data$order)
cst <- chisq.test(matrix)
cst$p.value
matrix <- table(data$B_time, data$used_A)
cst <- chisq.test(matrix)
cst$p.value

matrix <- table(data$A_score, data$order)
cst <- chisq.test(matrix)
cst$p.value

matrix <- table(data$B_score, data$order)
cst <- chisq.test(matrix)
cst$p.value

matrix <- table(data$A_time, data$order)
cst <- chisq.test(matrix)
cst$p.value

matrix <- table(data$B_time, data$order)
cst <- chisq.test(matrix)
cst$p.value

matrix <- table(data$A_use, data$order)
cst <- chisq.test(matrix)
cst$p.value

matrix <- table(data$B_use, data$order)
cst <- chisq.test(matrix)
cst$p.value

matrix <- table(data$A_perf, data$order)
cst <- chisq.test(matrix)
cst$p.value

matrix <- table(data$B_perf, data$order)
cst <- chisq.test(matrix)
cst$p.value
